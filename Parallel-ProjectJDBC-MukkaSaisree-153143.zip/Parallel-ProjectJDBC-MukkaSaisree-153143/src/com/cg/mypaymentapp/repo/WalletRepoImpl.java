package com.cg.mypaymentapp.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.util.DBUtil;

public class WalletRepoImpl implements WalletRepo {

	@Override
	public boolean save(Customer customer) {
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement("insert into Customer1 values(?,?,?)");

			pstm.setString(1, customer.getName());
			pstm.setString(2, customer.getMobileNo());
			pstm.setBigDecimal(3, customer.getWallet().getBalance());

			pstm.execute();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public Customer findOne(String mobileNo) {
		Customer customer = null;
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement("select * from Customer1 WHERE mobileno=?");
			pstm.setString(1, mobileNo);
			ResultSet rs = pstm.executeQuery();

			if (rs.next() != false) {
				customer = new Customer();
				customer.setName(rs.getString(1));
				customer.setMobileNo(rs.getString(2));
				Wallet wal = new Wallet(rs.getBigDecimal(3));
				customer.setWallet(wal);
			} else {
				return null;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;

	}

}
